require 'test_helper'

class SandwichIngredientTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
